# TD Add

A simple repository to test the following Github Actions:
- Install dependencies
- Run eslint
- Run jest
- NPM publish
- Github pages publish
